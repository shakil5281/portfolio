window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
    document.getElementById("navbar").style.padding = "20px 10px";
    document.getElementById("navbar").style.backgroundColor = "rgb(62 62 62)";
    document.getElementById("logo").style.fontSize = "1.5rem";
    document.getElementById("logo").style.transition = ".4s";

  } else {
    document.getElementById("navbar").style.padding = "40px 10px";
    document.getElementById("navbar").style.backgroundColor = "#00800000";
    document.getElementById("logo").style.fontSize = "2rem";
    document.getElementById("logo").style.transition = ".4s";
  }
}